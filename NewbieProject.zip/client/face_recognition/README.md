# Facial-Recognition
Facial Recognition with Open-Cv Python

Prerequisite:

Python 3.x

Open-Cv Python 

Web Cam


Run Process:

First Step--> 

Put them in a single folder. Create a folder name faces.


Second Step-->

First, run Facial_Recognition_Part1.py. It will take your 100-copy picture for training the machine. The photos will be stored in the faces folder.

Third Step-->

Then run the Facial_Recognition_Part2.py. This is to train your machine.

Fourth Step-->

Then run the Facial_Recognition_Part3.py. This will give the output.
